package com.example.matapp_25_01_24;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {
    EditText personName, personSurname, editTime, editTime2;
    Button add_button, BtnBck;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_add);

        personName = findViewById(R.id.personName);
        personSurname = findViewById(R.id.personSurname);
        editTime = findViewById(R.id.editTime);
        editTime2 = findViewById(R.id.editTime2);
        add_button = findViewById(R.id.add_button);
        BtnBck = findViewById(R.id.BackBtn);

        BtnBck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEditTextEmpty(personName) || isEditTextEmpty(personSurname)
                        || isEditTextEmpty(editTime) || isEditTextEmpty(editTime2)) {
                    Toast.makeText(AddActivity.this, "Prosím, vyplňte všechna pole.", Toast.LENGTH_SHORT).show();
                    return;
                }
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddActivity.this);
                myDB.addAttendance(personName.getText().toString().trim(),
                        personSurname.getText().toString().trim(),
                        editTime.getText().toString().trim(),
                        editTime2.getText().toString().trim());

                // Vytvoření intentu pro přenos nově přidaných dat zpět do předchozí aktivity
                Intent intent = new Intent();
                intent.putExtra("newName", personName.getText().toString().trim());
                intent.putExtra("newSurname", personSurname.getText().toString().trim());
                intent.putExtra("newArrival", editTime.getText().toString().trim());
                intent.putExtra("newDeparture", editTime2.getText().toString().trim());
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
    private boolean isEditTextEmpty(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }
}
