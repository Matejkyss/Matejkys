package com.example.matapp_25_01_24;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateActivity extends AppCompatActivity {
    EditText personName, personSurname, editTime, editTime2;
    Button update_button, delete_button, BckBtn;
    String id, name, surname, arrival, departure;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_update);

        personName = findViewById(R.id.personName2);
        personSurname = findViewById(R.id.personSurname2);
        editTime = findViewById(R.id.editTime3);
        editTime2= findViewById(R.id.editTime4);
        update_button = findViewById(R.id.update_button);
        delete_button = findViewById(R.id.delete_button);
        BckBtn = findViewById(R.id.BckBtn);
        //nastaveni ab a jmena
        getAndSetIntentData();

        BckBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isEditTextEmpty(personName) || isEditTextEmpty(personSurname)
                        || isEditTextEmpty(editTime) || isEditTextEmpty(editTime2)) {
                    Toast.makeText(UpdateActivity.this, "Prosím, vyplňte všechna pole.", Toast.LENGTH_SHORT).show();
                    return;
                }

                update_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // Pokračování s aktualizací dat
                        MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
                        name = personName.getText().toString().trim();
                        surname = personSurname.getText().toString().trim();
                        arrival = editTime.getText().toString().trim();
                        departure = editTime2.getText().toString().trim();
                        myDB.updateData(id, name, surname, arrival, departure);
                    }
                });
                //prvni volame tohle
                MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
                // a potom tohle
                name=personName.getText().toString().trim();
                surname=personSurname.getText().toString().trim();
                arrival=editTime.getText().toString().trim();
                departure=editTime2.getText().toString().trim();
                myDB.updateData(id, name, surname, arrival, departure);

                // Vytvoření intentu pro přenos nových dat zpět do předchozí aktivity
                Intent intent = new Intent();
                intent.putExtra("updatedName", name);
                intent.putExtra("updatedSurname", surname);
                intent.putExtra("updatedArrival", arrival);
                intent.putExtra("updatedDeparture", departure);
                setResult(RESULT_OK, intent);
                finish();

            }
        });
        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
            }
        });
    }

    void getAndSetIntentData(){
        if (getIntent().hasExtra("id") && getIntent().hasExtra("name") && getIntent().hasExtra("surname")
                && getIntent().hasExtra("arrival") && getIntent().hasExtra("departure")){
            //ziskavani infa z intentu
            id = getIntent().getStringExtra("id");
            name = getIntent().getStringExtra("name");
            surname = getIntent().getStringExtra("surname");
            arrival = getIntent().getStringExtra("arrival");
            departure = getIntent().getStringExtra("departure");
            //nastavovani intentu data
            personName.setText(name);
            personSurname.setText(surname);
            editTime.setText(arrival);
            editTime2.setText(departure);
        }else{
            Toast.makeText(this, "Žádná data", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Smazat " + surname + "?");
        builder.setMessage("Jste si jistý že chete vymazat " + surname + " ?");
        builder.setPositiveButton("ANO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
                myDB.deleteOneRow(id);
                finish();
            }
        });
        builder.setNegativeButton("NE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }
    private boolean isEditTextEmpty(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }
}


