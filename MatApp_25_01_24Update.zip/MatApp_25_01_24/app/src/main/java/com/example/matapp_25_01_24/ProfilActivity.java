package com.example.matapp_25_01_24;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class ProfilActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    FloatingActionButton add_button;
    MyDatabaseHelper myDB;
    ArrayList<String> id, name, name_surname, time1, time2;
    CustomAdapter customAdapter;
    Button buttonBCK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);
        //dekladace promenych pro jednotlive komponenty

        recyclerView = findViewById(R.id.recyklerView);
        add_button = findViewById(R.id.add_button);
        buttonBCK = findViewById(R.id.buttonBCK);
        buttonBCK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        add_button.setOnClickListener(new View.OnClickListener() {

            // Nastavení posluchače události kliknutí na tlačítko pro přidání nových záznamů
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfilActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });
        // Inicializace instance MyDatabaseHelper a polí pro uchování dat
        myDB = new MyDatabaseHelper(ProfilActivity.this);
        id = new ArrayList<>();
        name = new ArrayList<>();
        name_surname = new ArrayList<>();
        time1 = new ArrayList<>();
        time2 = new ArrayList<>();

        storeDataInArrays();

        // Inicializace a nastavení CustomAdapteru pro RecyclerView
        customAdapter = new CustomAdapter(ProfilActivity.this,this,  id, name, name_surname, time1, time2);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(ProfilActivity.this));

        }
        // automaticky update kdyz chceme upravit dochazku
         @Override
         protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
                super.onActivityResult(requestCode, resultCode, data);
                if (requestCode == 1){
                recreate();
        }
    }
    //nacita data z databaze a uklidani do poli
    void storeDataInArrays(){
        Cursor cursor = myDB.readAllData();
        if(cursor.getCount() == 0) {

        }else {
            while (cursor.moveToNext()) {
                id.add(cursor.getString(0));
                name.add(cursor.getString(1));
                name_surname.add(cursor.getString(2));
                time1.add(cursor.getString(3));
                time2.add(cursor.getString(4));
            }
            //kdyz nejsou data

        }
    }}


