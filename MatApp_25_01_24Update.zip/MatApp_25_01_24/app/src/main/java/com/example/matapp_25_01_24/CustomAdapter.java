package com.example.matapp_25_01_24;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder>  {
    private Context context;
    Activity activity;
    private ArrayList id, name, name_surname, time1, time2;

    CustomAdapter(Activity activity,Context context, ArrayList id, ArrayList name, ArrayList name_surname, ArrayList time1, ArrayList time2) {
        this.activity = activity;
        this.context = context;
        this.name = name;
        this.name_surname = name_surname;
        this.time1 = time1;
        this.time2 = time2;
        this.id = id;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_profil_adapter, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.id_txt.setText(String.valueOf(id.get(position)));
        holder.name_txt.setText(String.valueOf(name.get(position)));
        holder.surname_txt.setText(String.valueOf(name_surname.get(position)));
        holder.arrival_txt.setText(String.valueOf(time1.get(position)));
        holder.departure_txt.setText(String.valueOf(time2.get(position)));
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("id", String.valueOf(id.get(position)));
                intent.putExtra("name", String.valueOf(name.get(position)));
                intent.putExtra("surname", String.valueOf(name_surname.get(position)));
                intent.putExtra("arrival", String.valueOf(time1.get(position)));
                intent.putExtra("departure", String.valueOf(time2.get(position)));
                activity.startActivityForResult(intent, 1 );
            }
        });
        }

    private boolean isEditTextEmpty(TextView editText) {
        return editText.getText().toString().trim().isEmpty();
    }
    @Override
    public int getItemCount() {
        return id.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView id_txt, name_txt, surname_txt, arrival_txt, departure_txt;
        Button delete_btn;
        LinearLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            id_txt = itemView.findViewById(R.id.id_txt);
            name_txt = itemView.findViewById(R.id.idecko);
            surname_txt = itemView.findViewById(R.id.timeA);
            arrival_txt = itemView.findViewById(R.id.timeD);
            departure_txt = itemView.findViewById(R.id.departure_txt);
            mainLayout = itemView.findViewById(R.id.mainLayout);

        }
    }
}




