package com.example.matapp_25_01_24;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button mBtnD, mBtnP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //...proklik z main na dochazku
        Button mBtnD = findViewById(R.id.mBtnD);
        mBtnD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent pro přechod na DruhaAktivita
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);
            }
            });
        //...prokliky z main na profily
        Button mBtnP = findViewById(R.id.mBtnP);
        mBtnP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vi) {
                // Intent pro přechod na DruhaAktivita
                Intent intent = new Intent(MainActivity.this, ProfilActivity.class);
                startActivity(intent);
            }
        });
    }
}